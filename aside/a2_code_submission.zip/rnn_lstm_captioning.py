import math
from typing import Optional, Tuple

import torch
import torchvision
from torch import nn
from torch.nn import functional as F
from torchvision.models import feature_extraction

#itai kahana
def hello_rnn_lstm_captioning():
    print("Hello from rnn_lstm_captioning.py!")


class ImageEncoder(nn.Module):
    """
    Convolutional network that accepts images as input and outputs their spatial
    grid features. This module servesx as the image encoder in image captioning
    model. We will use a tiny RegNet-X 400MF model that is initialized with
    ImageNet-pretrained weights from Torchvision library.

    NOTE: We could use any convolutional network/image encoder architecture, but we opt for a
    tiny RegNet model so it can train decently with a single Colab GPU.
    """

    def __init__(self, pretrained: bool = True, verbose: bool = True):
        """
        Args:
            pretrained: Whether to initialize this model with pretrained weights
                from Torchvision library.
            verbose: Whether to log expected output shapes during instantiation.
        """
        super().__init__()
        self.cnn = torchvision.models.regnet_x_400mf(pretrained=pretrained)

        # Torchvision models return global average pooled features by default.
        # Our attention-based models may require spatial grid features. So we
        # wrap the ConvNet with torchvision's feature extractor. We will get
        # the spatial features right before the final classification layer.
        self.backbone = feature_extraction.create_feature_extractor(
            self.cnn, return_nodes={"trunk_output.block4": "c5"}
        )
        # We call these features "c5", a name that may sound familiar from the
        # object detection assignment. :-)

        # Pass a dummy batch of input images to infer output shape.
        dummy_out = self.backbone(torch.randn(2, 3, 224, 224))["c5"]
        self._out_channels = dummy_out.shape[1]

        if verbose:
            print("For input images in NCHW format, shape (2, 3, 224, 224)")
            print(f"Shape of output c5 features: {dummy_out.shape}")

        # Input image batches are expected to be float tensors in range [0, 1].
        # However, the backbone here expects these tensors to be normalized by
        # ImageNet color mean/std (as it was trained that way).
        # We define a function to transform the input images before extraction:
        self.normalize = torchvision.transforms.Normalize(
            mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
        )

    @property
    def out_channels(self):
        """
        Number of output channels in extracted image features. You may access
        this value freely to define more modules to go with this encoder.
        """
        return self._out_channels

    def forward(self, images: torch.Tensor):
        # Input images may be uint8 tensors in [0-255], change them to float
        # tensors in [0-1]. Get float type from backbone (could be float32/64).
        if images.dtype == torch.uint8:
            images = images.to(dtype=self.cnn.stem[0].weight.dtype)
            images /= 255.0

        # Normalize images by ImageNet color mean/std.
        images = self.normalize(images)

        # Extract c5 features from encoder (backbone) and return.
        # shape: (B, out_channels, H / 32, W / 32)
        features = self.backbone(images)["c5"]
        return features

##############################################################################
# Recurrent Neural Network                                                   #
##############################################################################
def rnn_step_forward(x, prev_h, Wx, Wh, b):
    """
    Run the forward pass for a single timestep of a vanilla RNN that uses a tanh
    activation function.

    The input data has dimension D, the hidden state has dimension H, and we use
    a minibatch size of N.

    Args:
        x: Input data for this timestep, of shape (N, D).
        prev_h: Hidden state from previous timestep, of shape (N, H)
        Wx: Weight matrix for input-to-hidden connections, of shape (D, H)
        Wh: Weight matrix for hidden-to-hidden connections, of shape (H, H)
        b: Biases, of shape (H,)

    Returns a tuple of:
        next_h: Next hidden state, of shape (N, H)
        cache: Tuple of values needed for the backward pass.
    """
    next_h, cache = None, None
    ##########################################################################
    # TODO: Implement a single forward step for the vanilla RNN. Store next
    # hidden state and any values you need for the backward pass in the next_h
    # and cache variables respectively.
    ##########################################################################
    # Replace "pass" statement with your code
        
    # Affine transform
    a = x @ Wx + prev_h @ Wh + b


    # Non-linearity
    next_h = torch.tanh(a)         # (N, H)

    # Cache (only needed if you implement backward manually)
    cache = (x, prev_h, Wx, Wh, a, next_h)

    ##########################################################################
    #                             END OF YOUR CODE                           #
    ##########################################################################
    return next_h, cache

def rnn_step_backward(dnext_h, cache):
    """
    Backward pass for a single timestep of a vanilla RNN.

    Args:
        dnext_h: Gradient of loss with respect to next hidden state, of shape (N, H)
        cache: Cache object from the forward pass

    Returns a tuple of:
        dx: Gradients of input data, of shape (N, D)
        dprev_h: Gradients of previous hidden state, of shape (N, H)
        dWx: Gradients of input-to-hidden weights, of shape (D, H)
        dWh: Gradients of hidden-to-hidden weights, of shape (H, H)
        db: Gradients of bias vector, of shape (H,)
    """
    dx, dprev_h, dWx, dWh, db = None, None, None, None, None
    ##########################################################################
    # TODO: Implement the backward pass for a single step of a vanilla RNN.
    #
    # HINT: For the tanh function, you can compute the local derivative in
    # terms of the output value from tanh.
    ##########################################################################
    # Replace "pass" statement with your code

    x, prev_h, Wx, Wh, a, next_h = cache  # a is optional; next_h is enough for tanh'

    # tanh'(a) = 1 - tanh(a)^2 = 1 - next_h^2
    da = dnext_h * (1 - next_h * next_h)  # (N, H)

    # a = x @ Wx + prev_h @ Wh + b
    dx = da @ Wx.T                        # (N, D)
    dprev_h = da @ Wh.T                   # (N, H)
    dWx = x.T @ da                        # (D, H)
    dWh = prev_h.T @ da                   # (H, H)
    db = da.sum(dim=0)                    # (H,)
    ##########################################################################
    #                             END OF YOUR CODE                           #
    ##########################################################################
    return dx, dprev_h, dWx, dWh, db


def rnn_forward(x, h0, Wx, Wh, b):
    """
    Run a vanilla RNN forward on an entire sequence of data. We assume an input
    sequence composed of T vectors, each of dimension D. The RNN uses a hidden
    size of H, and we work over a minibatch containing N sequences. After running
    the RNN forward, we return the hidden states for all timesteps.

    Args:
        x: Input data for the entire timeseries, of shape (N, T, D).
        h0: Initial hidden state, of shape (N, H)
        Wx: Weight matrix for input-to-hidden connections, of shape (D, H)
        Wh: Weight matrix for hidden-to-hidden connections, of shape (H, H)
        b: Biases, of shape (H,)

    Returns a tuple of:
        h: Hidden states for the entire timeseries, of shape (N, T, H).
        cache: Values needed in the backward pass
    """
    h, cache = None, None
    ##########################################################################
    # TODO: Implement forward pass for a vanilla RNN running on a sequence of
    # input data. You should use the rnn_step_forward function that you defined
    # above. You can use a for loop to help compute the forward pass.
    ##########################################################################
    # Replace "pass" statement with your code
    N, T, D = x.shape
    H = h0.shape[1]

    # allocate output
    h = x.new_empty((N, T, H))
    cache = []
    prev_h = h0
    

    for t in range(T):
        xt = x[:, t, :]                      # (N, D)
        next_h, step_cache = rnn_step_forward(xt, prev_h, Wx, Wh, b)
        h[:, t, :] = next_h
        cache.append(step_cache)
        prev_h = next_h

    ##########################################################################
    #                             END OF YOUR CODE                           #
    ##########################################################################
    return h, cache


def rnn_backward(dh, cache):
    """
    Compute the backward pass for a vanilla RNN over an entire sequence of data.

    Args:
        dh: Upstream gradients of all hidden states, of shape (N, T, H).

    NOTE: 'dh' contains the upstream gradients produced by the
    individual loss functions at each timestep, *not* the gradients
    being passed between timesteps (which you'll have to compute yourself
    by calling rnn_step_backward in a loop).

    Returns a tuple of:
        dx: Gradient of inputs, of shape (N, T, D)
        dh0: Gradient of initial hidden state, of shape (N, H)
        dWx: Gradient of input-to-hidden weights, of shape (D, H)
        dWh: Gradient of hidden-to-hidden weights, of shape (H, H)
        db: Gradient of biases, of shape (H,)
    """
    dx, dh0, dWx, dWh, db = None, None, None, None, None
    ##########################################################################
    # TODO: Implement the backward pass for a vanilla RNN running an entire
    # sequence of data. You should use the rnn_step_backward function that you
    # defined above. You can use a for loop to help compute the backward pass.
    ##########################################################################
    # Replace "pass" statement with your code
    T = len(cache)
    x0, _, Wx, Wh, _, _ = cache[0]  # unpack shapes
    N, D = x0.shape
    H = Wh.shape[0]

    # Allocate grads
    dx = dh.new_zeros((N, T, D))
    dWx = Wx.new_zeros(Wx.shape)
    dWh = Wh.new_zeros(Wh.shape)
    db = Wh.new_zeros((H,))

    dprev_h = dh.new_zeros((N, H))

    # Backprop through time
    for t in reversed(range(T)):
        # total gradient flowing into h_t
        dcur_h = dh[:, t, :] + dprev_h  # (N, H)

        # step backward
        dxt, dprev_h, dWxt, dWht, dbt = rnn_step_backward(dcur_h, cache[t])

        dx[:, t, :] = dxt
        dWx += dWxt
        dWh += dWht
        db += dbt

    dh0 = dprev_h  # after t=0, what's left is gradient w.r.t. initial hidden

    return dx, dh0, dWx, dWh, db

    ##########################################################################
    #                             END OF YOUR CODE                           #
    ##########################################################################
    return dx, dh0, dWx, dWh, db


class RNN(nn.Module):
    """
    Single-layer vanilla RNN module.

    You don't have to implement anything here but it is highly recommended to
    read through the code as you will implement subsequent modules.
    """

    def __init__(self, input_dim: int, hidden_dim: int):
        """
        Initialize an RNN. Model parameters to initialize:
            Wx: Weight matrix for input-to-hidden connections, of shape (D, H)
            Wh: Weight matrix for hidden-to-hidden connections, of shape (H, H)
            b: Biases, of shape (H,)

        Args:
            input_dim: Input size, denoted as D before
            hidden_dim: Hidden size, denoted as H before
        """
        super().__init__()

        # Register parameters
        self.Wx = nn.Parameter(
            torch.randn(input_dim, hidden_dim).div(math.sqrt(input_dim))
        )
        self.Wh = nn.Parameter(
            torch.randn(hidden_dim, hidden_dim).div(math.sqrt(hidden_dim))
        )
        self.b = nn.Parameter(torch.zeros(hidden_dim))

    def forward(self, x, h0):
        """
        Args:
            x: Input data for the entire timeseries, of shape (N, T, D)
            h0: Initial hidden state, of shape (N, H)

        Returns:
            hn: The hidden state output
        """
        hn, _ = rnn_forward(x, h0, self.Wx, self.Wh, self.b)
        return hn

    def step_forward(self, x, prev_h):
        """
        Args:
            x: Input data for one time step, of shape (N, D)
            prev_h: The previous hidden state, of shape (N, H)

        Returns:
            next_h: The next hidden state, of shape (N, H)
        """
        next_h, _ = rnn_step_forward(x, prev_h, self.Wx, self.Wh, self.b)
        return next_h


class WordEmbedding(nn.Module):
    """
    Simplified version of torch.nn.Embedding.

    We operate on minibatches of size N where
    each sequence has length T. We assume a vocabulary of V words, assigning each
    word to a vector of dimension D.

    Args:
        x: Integer array of shape (N, T) giving indices of words. Each element idx
      of x muxt be in the range 0 <= idx < V.

    Returns a tuple of:
        out: Array of shape (N, T, D) giving word vectors for all input words.
    """

    def __init__(self, vocab_size: int, embed_size: int):
        super().__init__()

        # Register parameters
        self.W_embed = nn.Parameter(
            torch.randn(vocab_size, embed_size).div(math.sqrt(vocab_size))
        )

    def forward(self, x):

        out = None
        ######################################################################
        # TODO: Implement the forward pass for word embeddings.
        ######################################################################
        # Replace "pass" statement with your code
        out = self.W_embed[x]
        ######################################################################
        #                           END OF YOUR CODE                         #
        ######################################################################
        return out


def temporal_softmax_loss(x, y, ignore_index=None):
    """
    A temporal version of softmax loss for use in RNNs. We assume that we are
    making predictions over a vocabulary of size V for each timestep of a
    timeseries of length T, over a minibatch of size N. The input x gives scores
    for all vocabulary elements at all timesteps, and y gives the indices of the
    ground-truth element at each timestep. We use a cross-entropy loss at each
    timestep, *summing* the loss over all timesteps and *averaging* across the
    minibatch.

    As an additional complication, we may want to ignore the model output at some
    timesteps, since sequences of different length may have been combined into a
    minibatch and padded with NULL tokens. The optional ignore_index argument
    tells us which elements in the caption should not contribute to the loss.

    Args:
        x: Input scores, of shape (N, T, V)
        y: Ground-truth indices, of shape (N, T) where each element is in the
            range 0 <= y[i, t] < V

    Returns a tuple of:
        loss: Scalar giving loss
    """
    loss = None

    ##########################################################################
    # TODO: Implement the temporal softmax loss function.
    #
    # REQUIREMENT: This part MUST be done in one single line of code!
    #
    # HINT: Look up the function torch.functional.cross_entropy, set
    # ignore_index to the variable ignore_index (i.e., index of NULL) and
    # set reduction to either 'sum' or 'mean' (avoid using 'none' for now).
    #
    # We use a cross-entropy loss at each timestep, *summing* the loss over
    # all timesteps and *averaging* across the minibatch.
    ##########################################################################
    # Replace "pass" statement with your code
    loss = torch.nn.functional.cross_entropy(x.reshape(-1, x.shape[2]), y.reshape(-1), ignore_index=ignore_index, reduction="sum") / x.shape[0]

    ##########################################################################
    #                             END OF YOUR CODE                           #
    ##########################################################################

    return loss


class CaptioningRNN(nn.Module):
    """
    A CaptioningRNN produces captions from images using a recurrent
    neural network.

    The RNN receives input vectors of size D, has a vocab size of V, works on
    sequences of length T, has an RNN hidden dimension of H, uses word vectors
    of dimension W, and operates on minibatches of size N.

    Note that we don't use any regularization for the CaptioningRNN.

    You will implement the `__init__` method for model initialization and
    the `forward` method first, then come back for the `sample` method later.
    """

    def __init__(
        self,
        word_to_idx,
        input_dim: int = 512,
        wordvec_dim: int = 128,
        hidden_dim: int = 128,
        cell_type: str = "rnn",
        image_encoder_pretrained: bool = True,
        ignore_index: Optional[int] = None,
    ):
        """
        Construct a new CaptioningRNN instance.

        Args:
            word_to_idx: A dictionary giving the vocabulary. It contains V
                entries, and maps each string to a unique integer in the
                range [0, V).
            input_dim: Dimension D of input image feature vectors.
            wordvec_dim: Dimension W of word vectors.
            hidden_dim: Dimension H for the hidden state of the RNN.
            cell_type: What type of RNN to use; either 'rnn' or 'lstm'.
        """
        super().__init__()
        if cell_type not in {"rnn", "lstm", "attn"}:
            raise ValueError('Invalid cell_type "%s"' % cell_type)

        self.cell_type = cell_type
        self.word_to_idx = word_to_idx
        self.idx_to_word = {i: w for w, i in word_to_idx.items()}

        vocab_size = len(word_to_idx)

        self._null = word_to_idx["<NULL>"]
        self._start = word_to_idx.get("<START>", None)
        self._end = word_to_idx.get("<END>", None)
        self.ignore_index = ignore_index

        ######################################################################
        # TODO: Initialize the image captioning module. Refer to the TODO
        # in the captioning_forward function on layers you need to create
        #
        # You may want to check the following pre-defined classes:
        # ImageEncoder WordEmbedding, RNN, LSTM, AttentionLSTM, nn.Linear
        #
        # (1) output projection (from RNN hidden state to vocab probability)
        # (2) feature projection (from CNN pooled feature to h0)
        ######################################################################
        # Replace "pass" statement with your code


        
        # ---------- Encoder ----------
        # ImageEncoder returns spatial grid features: (B, C, H', W')
        self.image_encoder = ImageEncoder(pretrained=image_encoder_pretrained)

        # If input_dim wasn't set to match encoder channels, use encoder channels.
        # This keeps the API stable and prevents silent shape mismatches.
        enc_dim = self.image_encoder.out_channels
        if input_dim != enc_dim:
            input_dim = enc_dim

        # ---------- Word embedding ----------
        self.word_embedding = WordEmbedding(vocab_size=vocab_size, embed_size=wordvec_dim)

        # ---------- Feature projection ----------
        # rnn/lstm: pooled feature (B, C) -> h0 (B, H)
        self.feat_proj = nn.Linear(input_dim, hidden_dim)

        # attn: per-location feature (B, C, H', W') -> projected (B, H, H', W')
        # Same in/out dims as feat_proj, but applied to a different tensor shape.
        self.attn_feat_proj = nn.Linear(input_dim, hidden_dim)

        # ---------- Recurrent core ----------
        if self.cell_type == "rnn":
            self.core = RNN(input_dim=wordvec_dim, hidden_dim=hidden_dim)
        elif self.cell_type == "lstm":
            self.core = LSTM(input_dim=wordvec_dim, hidden_dim=hidden_dim)
        elif self.cell_type == "attn":  # "attn"
            self.core = AttentionLSTM(input_dim=wordvec_dim, hidden_dim=hidden_dim)

        # ---------- Output projection ----------
        self.out_proj = nn.Linear(hidden_dim, vocab_size)


        ######################################################################
        #                            END OF YOUR CODE                        #
        ######################################################################

    def forward(self, images, captions):
        """
        Compute training-time loss for the RNN. We input images and the GT
        captions for those images, and use an RNN (or LSTM) to compute loss. The
        backward part will be done by torch.autograd.

        Args:
            images: Input images, of shape (N, 3, 112, 112)
            captions: Ground-truth captions; an integer array of shape (N, T + 1)
                where each element is in the range 0 <= y[i, t] < V

        Returns:
            loss: A scalar loss
        """
        # Cut captions into two pieces: captions_in has everything but the last
        # word and will be input to the RNN; captions_out has everything but the
        # first word and this is what we will expect the RNN to generate. These
        # are offset by one relative to each other because the RNN should produce
        # word (t+1) after receiving word t. The first element of captions_in
        # will be the START token, and the first element of captions_out will
        # be the first word.
        captions_in = captions[:, :-1]
        captions_out = captions[:, 1:]

        loss = 0.0
        ######################################################################
        # TODO: Implement the forward pass for the CaptioningRNN.
        # In the forward pass you will need to do the following:
        # (1) Use an affine transformation to project the image feature to
        #     the initial hidden state $h0$ (for RNN/LSTM, of shape (N, H)) or
        #     the projected CNN activation input $A$ (for Attention LSTM,
        #     of shape (N, H, 4, 4).
        # (2) Use a word embedding layer to transform the words in captions_in
        #     from indices to vectors, giving an array of shape (N, T, W).
        # (3) Use either a vanilla RNN or LSTM (depending on self.cell_type) to
        #     process the sequence of input word vectors and produce hidden state
        #     vectors for all timesteps, producing an array of shape (N, T, H).
        # (4) Use a (temporal) affine transformation to compute scores over the
        #     vocabulary at every timestep using the hidden states, giving an
        #     array of shape (N, T, V).
        # (5) Use (temporal) softmax to compute loss using captions_out, ignoring
        #     the points where the output word is <NULL>.
        #
        # Do not worry about regularizing the weights or their gradients!
        ######################################################################
        # Replace "pass" statement with your code


        ignore = self._null if self.ignore_index is None else self.ignore_index

        # (2) word embeddings for inputs: (N, T, W)
        x_embed = self.word_embedding(captions_in)

        # (1) encode image -> spatial features: (N, C, H', W')
        img_spatial = self.image_encoder(images)

        if self.cell_type in {"rnn", "lstm"}:
            # For vanilla RNN/LSTM we use average pooled features: (N, C)
            img_feat = img_spatial.mean(dim=(2, 3))

            # Project pooled feature -> initial hidden state h0: (N, H)
            h0 = self.feat_proj(img_feat)


            # (2) run RNN: (N, T, W) + (N, H) -> (N, T, H)
            h = self.core(x_embed, h0)


        else:
            A = self.attn_feat_proj(img_spatial.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)  # (N, H, 4, 4)
            # ------------------------------------------------------------
            # 2) run AttentionLSTM over word embeddings using A
            # ------------------------------------------------------------
            h = self.core(x_embed, A)  # (N, T, H)

        # (3) vocab scores: (N, T, V)
        scores = self.out_proj(h)

        # (4) temporal softmax loss (ignoring <NULL>)
        loss = temporal_softmax_loss(scores, captions_out, ignore_index=ignore)

        ######################################################################
        #                           END OF YOUR CODE                         #
        ######################################################################

        return loss

    def sample(self, images, max_length=15):
        """
        Run a test-time forward pass for the model, sampling captions for input
        feature vectors.

        At each timestep, we embed the current word, pass it and the previous hidden
        state to the RNN to get the next hidden state, use the hidden state to get
        scores for all vocab words, and choose the word with the highest score as
        the next word. The initial hidden state is computed by applying an affine
        transform to the image features, and the initial word is the <START>
        token.

        For LSTMs you will also have to keep track of the cell state; in that case
        the initial cell state should be zero.

        Args:
            images: Input images, of shape (N, 3, 112, 112)
            max_length: Maximum length T of generated captions

        Returns:
            captions: Array of shape (N, max_length) giving sampled captions,
                where each element is an integer in the range [0, V). The first
                element of captions should be the first sampled word, not the
                <START> token.
        """
        N = images.shape[0]
        captions = self._null * images.new(N, max_length).fill_(1).long()

        if self.cell_type == "attn":
            attn_weights_all = images.new(N, max_length, 4, 4).fill_(0).float()

        ######################################################################
        # TODO: Implement test-time sampling for the model. You will need to
        # initialize the hidden state of the RNN by applying the learned affine
        # transform to the image features. The first word that you feed to
        # the RNN should be the <START> token; its value is stored in the
        # variable self._start. At each timestep you will need to do to:
        # (1) Embed the previous word using the learned word embeddings
        # (2) Make an RNN step using the previous hidden state and the embedded
        #     current word to get the next hidden state.
        # (3) Apply the learned affines transformation to the next hidden state to
        #     get scores for all words in the vocabulary
        # (4) Select the word with the highest score as the next word, writing it
        #     (the word index) to the appropriate slot in the captions variable
        #
        # For simplicity, you do not need to stop generating after an <END> token
        # is sampled, but you can if you want to.
        #
        # NOTE: we are still working over minibatches in this function. Also if
        # you are using an LSTM, initialize the first cell state to zeros.
        # For AttentionLSTM, first project the 1280x4x4 CNN feature activation
        # to $A$ of shape Hx4x4. The LSTM initial hidden state and cell state
        # would both be A.mean(dim=(2, 3)).
        #######################################################################
        # Replace "pass" statement with your code

        
        if self.cell_type not in {"rnn", "lstm", "attn"}:
            raise ValueError(f"Unknown cell_type: {self.cell_type}")

        # ------------------------------------------------------------
        # 0) Encode images -> spatial CNN features
        #    ImageEncoder returns: (N, C, H', W')
        # ------------------------------------------------------------
        img_spatial = self.image_encoder(images)

        # ------------------------------------------------------------
        # 1) Initialize hidden state (and cell state if LSTM)
        # ------------------------------------------------------------


        # if self.cell_type in {"rnn", "lstm"}:
        #     img_pooled = img_spatial.mean(dim=(2, 3))   # (N, C)
        #     h = self.feat_proj(img_pooled)              # (N, H)
        #     if self.cell_type == "lstm":
        #         c = torch.zeros_like(h)                 # (N, H)

        # elif self.cell_type == "attn":
        #     # Project CNN spatial activation to A: (N, H, 4, 4)
        #     A = self.attn_feat_proj(img_spatial.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)  # (N,H,4,4)
        #     # Initial h and c are meanpooled A (per instructions)
        #     h = A.mean(dim=(2, 3))   # (N, H)
        #     c = h                    # (N, H)


        # For RNN/LSTM we use average-pooled features: (N, C)
        img_pooled = img_spatial.mean(dim=(2, 3))

        # Initial hidden state h0: (N, H)
        h = self.feat_proj(img_pooled)

        # For LSTM also initialize c0 to zeros
        c = torch.zeros_like(h)

        if self.cell_type == "attn":
            # Project CNN spatial activation to A: (N, H, 4, 4)
            A = self.attn_feat_proj(img_spatial.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)  # (N,H,4,4)
            # Initial h and c are meanpooled A (per instructions)
            h = A.mean(dim=(2, 3))   # (N, H)
            c = h                    # (N, H)



        # elif self.cell_type == "attn":
        #     # TODO: AttentionLSTM sampling will be implemented later in this assignment.
        #     # Steps required by instructions:
        #     #  - project CNN spatial activation to A of shape (N, H, 4, 4)
        #     #  - initialize h and c as A.mean(dim=(2, 3))
        #     #  - run per-timestep attention LSTM step and store attn weights
        #     raise NotImplementedError("TODO: implement AttentionLSTM.sample later")



        # ------------------------------------------------------------
        # 2) First input word is <START>
        # ------------------------------------------------------------
        prev_word = torch.full(
            (N,),
            self._start,
            dtype=torch.long,
            device=images.device,
        )

        # ------------------------------------------------------------
        # 3) Autoregressive sampling loop
        #    For each timestep:
        #      (1) embed prev word
        #      (2) RNN step -> next hidden
        #      (3) hidden -> vocab scores
        #      (4) argmax -> next word, write into captions
        # ------------------------------------------------------------
        for t in range(max_length):
            # (1) embed previous word
            x_t = self.word_embedding(prev_word.unsqueeze(1)).squeeze(1)  # (N, W)

            if self.cell_type == "rnn":
                # (2) one RNN step
                h = self.core.step_forward(x_t, h)  # (N,H)

            elif self.cell_type == "lstm":
                # (2) one LSTM step
                h, c = self.core.step_forward(x_t, h, c)

            else:  # "attn"
                # (a) attention from prev hidden state + A
                attn, attn_w = dot_product_attention(h, A)      # attn: (N,H), attn_w: (N,4,4)
                attn_weights_all[:, t] = attn_w                 # store weights
                # (b) one AttentionLSTM step
                h, c = self.core.step_forward(x_t, h, c, attn)  # (N,H), (N,H)

            # (3) scores over vocab
            scores = self.out_proj(h)  # (N, V)

            # (4) greedy next token
            next_word = scores.argmax(dim=1)  # (N,)

            captions[:, t] = next_word
            prev_word = next_word
        ######################################################################
        #                           END OF YOUR CODE                         #
        ######################################################################
        if self.cell_type == "attn":
            return captions, attn_weights_all.cpu()
        else:
            return captions


class LSTM(nn.Module):
    """Single-layer, uni-directional LSTM module."""

    def __init__(self, input_dim: int, hidden_dim: int):
        """
        Initialize a LSTM. Model parameters to initialize:
            Wx: Weights for input-to-hidden connections, of shape (D, 4H)
            Wh: Weights for hidden-to-hidden connections, of shape (H, 4H)
            b: Biases, of shape (4H,)

        Args:
            input_dim: Input size, denoted as D before
            hidden_dim: Hidden size, denoted as H before
        """
        super().__init__()

        # Register parameters
        self.Wx = nn.Parameter(
            torch.randn(input_dim, hidden_dim * 4).div(math.sqrt(input_dim))
        )
        self.Wh = nn.Parameter(
            torch.randn(hidden_dim, hidden_dim * 4).div(math.sqrt(hidden_dim))
        )
        self.b = nn.Parameter(torch.zeros(hidden_dim * 4))

    def step_forward(
        self, x: torch.Tensor, prev_h: torch.Tensor, prev_c: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass for a single timestep of an LSTM.
        The input data has dimension D, the hidden state has dimension H, and
        we use a minibatch size of N.

        Args:
            x: Input data for one time step, of shape (N, D)
            prev_h: The previous hidden state, of shape (N, H)
            prev_c: The previous cell state, of shape (N, H)
            Wx: Input-to-hidden weights, of shape (D, 4H)
            Wh: Hidden-to-hidden weights, of shape (H, 4H)
            b: Biases, of shape (4H,)

        Returns:
            Tuple[torch.Tensor, torch.Tensor]
                next_h: Next hidden state, of shape (N, H)
                next_c: Next cell state, of shape (N, H)
        """
        ######################################################################
        # TODO: Implement the forward pass for a single timestep of an LSTM.
        ######################################################################
        next_h, next_c = None, None
        # Replace "pass" statement with your code
        
        # (1) Affine transformation
        # a shape: (N, 4H)
        a = x @ self.Wx + prev_h @ self.Wh + self.b

        H = prev_h.shape[1]

        # (2) Split activations
        ai = a[:, :H]        # input gate
        af = a[:, H:2*H]     # forget gate
        ao = a[:, 2*H:3*H]   # output gate
        ag = a[:, 3*H:]      # block input

        # (3) Apply nonlinearities
        i = torch.sigmoid(ai)
        f = torch.sigmoid(af)
        o = torch.sigmoid(ao)
        g = torch.tanh(ag)

        # (4) Cell state update
        next_c = f * prev_c + i * g

        # (5) Hidden state update
        next_h = o * torch.tanh(next_c)
        ######################################################################
        #                           END OF YOUR CODE                         #
        ######################################################################
        return next_h, next_c

    def forward(self, x: torch.Tensor, h0: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for an LSTM over an entire sequence of data. We assume an
        input sequence composed of T vectors, each of dimension D. The LSTM
        uses a hidden size of H, and we work over a minibatch containing N
        sequences. After running the LSTM forward, we return the hidden states
        for all timesteps.

        Note that the initial cell state is passed as input, but the initial
        cell state is set to zero. Also note that the cell state is not returned;
        it is an internal variable to the LSTM and is not accessed from outside.

        Args:
            x: Input data for the entire timeseries, of shape (N, T, D)
            h0: Initial hidden state, of shape (N, H)

        Returns:
            hn: The hidden state output.
        """

        c0 = torch.zeros_like(
            h0
        )  # we provide the intial cell state c0 here for you!
        ######################################################################
        # TODO: Implement the forward pass for an LSTM over entire timeseries
        ######################################################################
        hn = None
        # Replace "pass" statement with your code
        
        N, T, _ = x.shape
        H = h0.shape[1]

        # allocate output
        hn = x.new_empty((N, T, H))

        h = h0
        c = c0

        for t in range(T):
            h, c = self.step_forward(x[:, t, :], h, c)  # (N,H), (N,H)
            hn[:, t, :] = h
        ######################################################################
        #                           END OF YOUR CODE                         #
        ######################################################################

        return hn


def dot_product_attention(prev_h, A):
    """
    A simple scaled dot-product attention layer.

    Args:
        prev_h: The LSTM hidden state from previous time step, of shape (N, H)
        A: **Projected** CNN feature activation, of shape (N, H, 4, 4),
         where H is the LSTM hidden state size

    Returns:
        attn: Attention embedding output, of shape (N, H)
        attn_weights: Attention weights, of shape (N, 4, 4)

    """
    N, H, D_a, _ = A.shape

    attn, attn_weights = None, None
    ##########################################################################
    # TODO: Implement the scaled dot-product attention we described earlier. #
    # You will use this function for `AttentionLSTM` forward and sample      #
    # functions. HINT: Make sure you reshape attn_weights back to (N, 4, 4)! #
    ##########################################################################
    # Replace "pass" statement with your code

    # Flatten spatial dims: (N, H, 16)
    A_flat = A.view(N, H, D_a * D_a)

    # Scores: (N, 16) = (N, 1, H) @ (N, H, 16), scaled by sqrt(H)
    scores = torch.bmm(prev_h.unsqueeze(1), A_flat).squeeze(1) / math.sqrt(H)

    # Attention weights over 16 locations: (N, 16)
    weights_flat = torch.softmax(scores, dim=1)

    # Attention embedding: (N, H) = (N, H, 16) @ (N, 16, 1)
    attn = torch.bmm(A_flat, weights_flat.unsqueeze(2)).squeeze(2)

    # Reshape weights back to (N, 4, 4)
    attn_weights = weights_flat.view(N, D_a, D_a)
    ##########################################################################
    #                             END OF YOUR CODE                           #
    ##########################################################################

    return attn, attn_weights


class AttentionLSTM(nn.Module):
    """
    This is our single-layer, uni-directional Attention module.

    Args:
        input_dim: Input size, denoted as D before
        hidden_dim: Hidden size, denoted as H before
    """

    def __init__(self, input_dim: int, hidden_dim: int):
        """
        Initialize a LSTM. Model parameters to initialize:
            Wx: Weights for input-to-hidden connections, of shape (D, 4H)
            Wh: Weights for hidden-to-hidden connections, of shape (H, 4H)
            Wattn: Weights for attention-to-hidden connections, of shape (H, 4H)
            b: Biases, of shape (4H,)
        """
        super().__init__()

        # Register parameters
        self.Wx = nn.Parameter(
            torch.randn(input_dim, hidden_dim * 4).div(math.sqrt(input_dim))
        )
        self.Wh = nn.Parameter(
            torch.randn(hidden_dim, hidden_dim * 4).div(math.sqrt(hidden_dim))
        )
        self.Wattn = nn.Parameter(
            torch.randn(hidden_dim, hidden_dim * 4).div(math.sqrt(hidden_dim))
        )
        self.b = nn.Parameter(torch.zeros(hidden_dim * 4))

    def step_forward(
        self,
        x: torch.Tensor,
        prev_h: torch.Tensor,
        prev_c: torch.Tensor,
        attn: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x: Input data for one time step, of shape (N, D)
            prev_h: The previous hidden state, of shape (N, H)
            prev_c: The previous cell state, of shape (N, H)
            attn: The attention embedding, of shape (N, H)

        Returns:
            next_h: The next hidden state, of shape (N, H)
            next_c: The next cell state, of shape (N, H)
        """

        #######################################################################
        # TODO: Implement forward pass for a single timestep of attention LSTM.
        # Feel free to re-use some of your code from `LSTM.step_forward()`.
        #######################################################################
        next_h, next_c = None, None
        # Replace "pass" statement with your code

        # Activation: (N, 4H)
        a = x @ self.Wx + prev_h @ self.Wh + attn @ self.Wattn + self.b

        H = prev_h.shape[1]
        a_i, a_f, a_o, a_g = a[:, :H], a[:, H:2*H], a[:, 2*H:3*H], a[:, 3*H:4*H]

        i = torch.sigmoid(a_i)
        f = torch.sigmoid(a_f)
        o = torch.sigmoid(a_o)
        g = torch.tanh(a_g)

        next_c = f * prev_c + i * g
        next_h = o * torch.tanh(next_c)

        ######################################################################
        #                           END OF YOUR CODE                         #
        ######################################################################
        return next_h, next_c

    def forward(self, x: torch.Tensor, A: torch.Tensor):
        """
        Forward pass for an LSTM over an entire sequence of data. We assume an
        input sequence composed of T vectors, each of dimension D. The LSTM uses
        a hidden size of H, and we work over a minibatch containing N sequences.
        After running the LSTM forward, we return hidden states for all timesteps.

        Note that the initial cell state is passed as input, but the initial cell
        state is set to zero. Also note that the cell state is not returned; it
        is an internal variable to the LSTM and is not accessed from outside.

        h0 and c0 are same initialized as the global image feature (meanpooled A)
        For simplicity, we implement scaled dot-product attention, which means in
        Eq. 4 of the paper (https://arxiv.org/pdf/1502.03044.pdf),
        f_{att}(a_i, h_{t-1}) equals to the scaled dot product of a_i and h_{t-1}.

        Args:
            x: Input data for the entire timeseries, of shape (N, T, D)
            A: The projected CNN feature activation, of shape (N, H, 4, 4)

        Returns:
            hn: The hidden state output
        """

        # The initial hidden state h0 and cell state c0 are initialized
        # differently in AttentionLSTM from the original LSTM and hence
        # we provided them for you.
        h0 = A.mean(dim=(2, 3))  # Initial hidden state, of shape (N, H)
        c0 = h0  # Initial cell state, of shape (N, H)

        ######################################################################
        # TODO: Implement the forward pass for an LSTM over an entire time-  #
        # series. You should use the `dot_product_attention` function that   #
        # is defined outside this module.                                    #
        ######################################################################
        hn = None
        # Replace "pass" statement with your code

        h = h0
        c = c0
        N, T, _ = x.shape
        H = h.shape[1]

        hn = x.new_empty(N, T, H)

        for t in range(T):
            # attention from previous hidden state
            attn, _ = dot_product_attention(h, A)   # attn: (N, H)

            # one step of attention LSTM
            h, c = self.step_forward(x[:, t, :], h, c, attn)  # (N,H), (N,H)

            # store hidden state
            hn[:, t, :] = h


        ######################################################################
        #                           END OF YOUR CODE                         #
        ######################################################################
        return hn
